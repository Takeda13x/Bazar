from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from ventas.controllers.login_view import login_view
from ventas.controllers.clientes_view import nuevo_cliente

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('ventas.urls')),  # <-- Incluye todas las rutas de ventas en raíz
    path('', lambda request: redirect('/login/')),  # Redirige raíz a /login/
    path('login/', login_view, name='login'),
    path('registro/', nuevo_cliente, name='registro_cliente'),
]
