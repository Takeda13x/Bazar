from django.urls import path
from ventas.controllers.login_view import (
    login_view, logout_view,
    admin_dashboard,
    cliente_comprar,
    carrito_agregar,
    carrito_ver,
    carrito_cancelar,
    carrito_confirmar
)
from ventas.controllers.productos_view import (
    lista_productos,
    nuevo_producto,
    editar_producto,
    eliminar_producto
)
from ventas.controllers.clientes_view import (
    lista_clientes,
    nuevo_cliente,
    editar_cliente,
    eliminar_cliente,
    registro_cliente,
)

urlpatterns = [
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),

    # Dashboard
    path('dashboard/', admin_dashboard, name='admin_dashboard'),

    # Productos
    path('productos/', lista_productos, name='lista_productos'),
    path('productos/nuevo/', nuevo_producto, name='nuevo_producto'),
    path('productos/editar/<int:id>/', editar_producto, name='editar_producto'),
    path('productos/eliminar/<int:id>/', eliminar_producto, name='eliminar_producto'),

    # Clientes
    path('clientes/', lista_clientes, name='lista_clientes'),
    path('clientes/nuevo/', nuevo_cliente, name='nuevo_cliente'),
    path('clientes/editar/<int:id>/', editar_cliente, name='editar_cliente'),
    path('clientes/eliminar/<int:id>/', eliminar_cliente, name='eliminar_cliente'),
    path('registro/', registro_cliente, name='registro_cliente'),

    # Cliente y carrito
    path('cliente/comprar/', cliente_comprar, name='cliente_comprar'),
    path('cliente/carrito/agregar/', carrito_agregar, name='carrito_agregar'),
    path('cliente/carrito/', carrito_ver, name='carrito_ver'),
    path('cliente/carrito/cancelar/', carrito_cancelar, name='carrito_cancelar'),
    path('cliente/carrito/confirmar/', carrito_confirmar, name='carrito_confirmar'),
]
