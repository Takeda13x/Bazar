from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from ventas.models import Producto, Cliente
from django.contrib.auth.models import User

def login_view(request):
    mensaje = ""
    if request.method == "POST":
        usuario = request.POST.get("usuario")
        contrasena = request.POST.get("contrasena")
        user = authenticate(request, username=usuario, password=contrasena)
        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect("admin_dashboard")
            else:
                return redirect("cliente_comprar")
        else:
            mensaje = "Usuario o contraseña incorrectos."
    return render(request, "login.html", {"mensaje": mensaje})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
@user_passes_test(lambda u: u.is_superuser)
def admin_dashboard(request):
    return render(request, "admin/dashboard.html")

@login_required
def cliente_comprar(request):
    productos = Producto.objects.filter(stock__gt=0)
    return render(request, "clientes/comprar.html", {"productos": productos})

@login_required
def carrito_agregar(request):
    if request.method == "POST":
        carrito = request.session.get("carrito", {})
        for key, value in request.POST.items():
            if key.startswith("cantidad_"):
                producto_id = key.split("_")[1]
                try:
                    cantidad = int(value)
                    if cantidad < 0:
                        cantidad = 0
                except:
                    cantidad = 0

                if cantidad > 0:
                    producto = Producto.objects.filter(id=producto_id).first()
                    if producto:
                        cantidad_actual = carrito.get(producto_id, 0)
                        # Limitar la cantidad al stock disponible
                        cantidad_total = min(cantidad_actual + cantidad, producto.stock)
                        carrito[producto_id] = cantidad_total
        request.session["carrito"] = carrito
    return redirect("cliente_comprar")

@login_required
def carrito_ver(request):
    carrito = request.session.get("carrito", {})
    productos = Producto.objects.filter(id__in=carrito.keys())
    carrito_detalle = []
    total = 0
    for producto in productos:
        cantidad = carrito.get(str(producto.id), 0)
        subtotal = producto.precio * cantidad
        total += subtotal
        carrito_detalle.append({
            "producto": producto,
            "cantidad": cantidad,
            "subtotal": subtotal,
        })

    mensaje_error = request.session.pop("mensaje_error", None)

    return render(request, "clientes/carrito.html", {
        "carrito_detalle": carrito_detalle,
        "total": total,
        "mensaje_error": mensaje_error,
    })

@login_required
def carrito_cancelar(request):
    request.session["carrito"] = {}
    return redirect("cliente_comprar")

@login_required
def carrito_confirmar(request):
    carrito = request.session.get("carrito", {})
    if not carrito:
        return redirect("cliente_comprar")

    productos = Producto.objects.filter(id__in=carrito.keys())
    total = 0
    resumen = []

    # Validar stock antes de procesar
    for producto in productos:
        cantidad = carrito.get(str(producto.id), 0)
        if cantidad > producto.stock:
            request.session["mensaje_error"] = f"No hay suficiente stock para el producto '{producto.nombre}'."
            return redirect("carrito_ver")
        subtotal = producto.precio * cantidad
        total += subtotal
        resumen.append({
            "producto": producto,
            "cantidad": cantidad,
            "subtotal": subtotal,
        })

    # Reducir stock y guardar
    for producto in productos:
        cantidad = carrito.get(str(producto.id), 0)
        producto.stock -= cantidad
        producto.save()

    request.session["carrito"] = {}

    return render(request, "clientes/boleta.html", {
        "resumen": resumen,
        "total": total,
        "usuario": request.user,
    })

@login_required
@user_passes_test(lambda u: u.is_superuser)
def lista_clientes(request):
    clientes = Cliente.objects.select_related('user').all()
    return render(request, 'clientes/lista.html', {'clientes': clientes})

def nuevo_cliente(request):
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        correo = request.POST.get('correo', '').strip()
        telefono = request.POST.get('telefono', '').strip()
        direccion = request.POST.get('direccion', '').strip()
        contrasena = request.POST.get('contrasena', '').strip()
        contrasena2 = request.POST.get('contrasena2', '').strip()

        if not nombre or not correo:
            mensaje_error = "Nombre y correo son obligatorios."
        elif not contrasena:
            mensaje_error = "La contraseña es obligatoria."
        elif contrasena != contrasena2:
            mensaje_error = "Las contraseñas no coinciden."
        elif User.objects.filter(username=nombre).exists():
            mensaje_error = "El nombre de usuario ya está en uso."

        if mensaje_error:
            return render(request, 'clientes/nuevo.html', {
                'mensaje_error': mensaje_error,
                'nombre': nombre,
                'correo': correo,
                'telefono': telefono,
                'direccion': direccion
            })

        user = User.objects.create_user(username=nombre, email=correo, password=contrasena)
        Cliente.objects.create(user=user, telefono=telefono, direccion=direccion)

        return redirect('login')

    return render(request, 'clientes/nuevo.html')
