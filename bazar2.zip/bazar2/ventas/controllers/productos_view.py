from django.shortcuts import render, redirect, get_object_or_404
from ventas.models import Producto

def lista_productos(request):
    productos = Producto.objects.all()
    return render(request, 'productos/lista.html', {'productos': productos})

def nuevo_producto(request):
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        descripcion = request.POST.get('descripcion', '').strip()
        precio = request.POST.get('precio', '').strip()
        stock = request.POST.get('stock', '').strip()

        # Validaciones
        if not nombre:
            mensaje_error = "El nombre es obligatorio."
        elif not precio or not precio.replace('.', '', 1).isdigit() or float(precio) <= 0:
            mensaje_error = "El precio debe ser un número positivo."
        elif not stock or not stock.isdigit() or int(stock) < 0:
            mensaje_error = "El stock debe ser un número entero igual o mayor a cero."

        if mensaje_error:
            return render(request, 'productos/nuevo.html', {
                'mensaje_error': mensaje_error,
                'nombre': nombre,
                'descripcion': descripcion,
                'precio': precio,
                'stock': stock
            })

        Producto.objects.create(
            nombre=nombre,
            descripcion=descripcion,
            precio=float(precio),
            stock=int(stock)
        )
        return redirect('lista_productos')

    return render(request, 'productos/nuevo.html')

def editar_producto(request, id):
    producto = get_object_or_404(Producto, id=id)
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        descripcion = request.POST.get('descripcion', '').strip()
        precio = request.POST.get('precio', '').strip()
        stock = request.POST.get('stock', '').strip()

        # Validaciones
        if not nombre:
            mensaje_error = "El nombre es obligatorio."
        elif not precio or not precio.replace('.', '', 1).isdigit() or float(precio) <= 0:
            mensaje_error = "El precio debe ser un número positivo."
        elif not stock or not stock.isdigit() or int(stock) < 0:
            mensaje_error = "El stock debe ser un número entero igual o mayor a cero."

        if mensaje_error:
            return render(request, 'productos/editar.html', {
                'producto': producto,
                'mensaje_error': mensaje_error,
                'nombre': nombre,
                'descripcion': descripcion,
                'precio': precio,
                'stock': stock
            })

        producto.nombre = nombre
        producto.descripcion = descripcion
        producto.precio = float(precio)
        producto.stock = int(stock)
        producto.save()
        return redirect('lista_productos')

    return render(request, 'productos/editar.html', {'producto': producto})

def eliminar_producto(request, id):
    producto = get_object_or_404(Producto, id=id)
    producto.delete()
    return redirect('lista_productos')
