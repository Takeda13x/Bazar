from django.shortcuts import redirect
from django.urls import reverse

def inicio_view(request):
    # Redirige a la lista de productos
    return redirect(reverse('lista_productos'))
