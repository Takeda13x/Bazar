from django.shortcuts import render, redirect, get_object_or_404
from ventas.models import Cliente
from django.contrib.auth.models import User

def lista_clientes(request):
    clientes = Cliente.objects.select_related('user').all()
    return render(request, 'clientes/lista.html', {'clientes': clientes})

def nuevo_cliente(request):
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        correo = request.POST.get('correo', '').strip()
        telefono = request.POST.get('telefono', '').strip()
        direccion = request.POST.get('direccion', '').strip()
        contrasena = request.POST.get('contrasena', '').strip()
        contrasena2 = request.POST.get('contrasena2', '').strip()

        if not nombre or not correo:
            mensaje_error = "Nombre y correo son obligatorios."
        elif not contrasena:
            mensaje_error = "La contraseña es obligatoria."
        elif contrasena != contrasena2:
            mensaje_error = "Las contraseñas no coinciden."
        elif User.objects.filter(username=nombre).exists():
            mensaje_error = "El nombre de usuario ya está en uso."

        if mensaje_error:
            return render(request, 'clientes/nuevo.html', {
                'mensaje_error': mensaje_error,
                'nombre': nombre,
                'correo': correo,
                'telefono': telefono,
                'direccion': direccion
            })

        # Crear usuario y cliente
        user = User.objects.create_user(username=nombre, email=correo, password=contrasena)
        Cliente.objects.create(user=user, telefono=telefono, direccion=direccion)

        return redirect('lista_clientes')

    return render(request, 'clientes/nuevo.html')

def editar_cliente(request, id):
    cliente = get_object_or_404(Cliente, id=id)
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        correo = request.POST.get('correo', '').strip()
        telefono = request.POST.get('telefono', '').strip()
        direccion = request.POST.get('direccion', '').strip()

        if not nombre or not correo:
            mensaje_error = "Nombre y correo son obligatorios."

        if mensaje_error:
            return render(request, 'clientes/editar.html', {
                'cliente': cliente,
                'mensaje_error': mensaje_error
            })

        # Actualiza User y Cliente
        user = cliente.user
        user.username = nombre
        user.email = correo
        user.save()

        cliente.telefono = telefono
        cliente.direccion = direccion
        cliente.save()

        return redirect('lista_clientes')

    return render(request, 'clientes/editar.html', {'cliente': cliente})

def eliminar_cliente(request, id):
    cliente = get_object_or_404(Cliente, id=id)
    user = cliente.user
    cliente.delete()
    user.delete()
    return redirect('lista_clientes')

def registro_cliente(request):
    mensaje_error = ""
    if request.method == 'POST':
        nombre = request.POST.get('nombre', '').strip()
        correo = request.POST.get('correo', '').strip()
        telefono = request.POST.get('telefono', '').strip()
        direccion = request.POST.get('direccion', '').strip()
        contrasena = request.POST.get('contrasena', '').strip()
        contrasena2 = request.POST.get('contrasena2', '').strip()

        if not nombre or not correo:
            mensaje_error = "Nombre y correo son obligatorios."
        elif not contrasena:
            mensaje_error = "La contraseña es obligatoria."
        elif contrasena != contrasena2:
            mensaje_error = "Las contraseñas no coinciden."
        elif User.objects.filter(username=nombre).exists():
            mensaje_error = "El nombre de usuario ya está en uso."

        if mensaje_error:
            return render(request, 'clientes/registro.html', {
                'mensaje_error': mensaje_error,
                'nombre': nombre,
                'correo': correo,
                'telefono': telefono,
                'direccion': direccion,
            })

        user = User.objects.create_user(username=nombre, email=correo, password=contrasena)
        Cliente.objects.create(user=user, telefono=telefono, direccion=direccion)

        return redirect('login')

    return render(request, 'clientes/registro.html')
