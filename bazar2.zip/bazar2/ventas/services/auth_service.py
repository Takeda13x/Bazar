from django.contrib.auth import authenticate

def autenticar_usuario(usuario, contrasena):
    # Devuelve el objeto user si las credenciales son correctas, sino None
    return authenticate(username=usuario, password=contrasena)
